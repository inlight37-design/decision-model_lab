const fs=require('fs'),os=require('os'),path=require('path');
const CC=require('./codex-peek/bridge/citation-check.js');
const root=fs.mkdtempSync(path.join(os.tmpdir(),'peek-review-semantics-'));
const file=path.join(root,'math.js');fs.writeFileSync(file,'function add(a,b) { return a+b; }\n');
const checked=CC.citationCheck({findings:[{id:'finding1',file:'math.js',line:1,detail:'`add` 함수는 모든 입력에 대해 영구적으로 데이터를 암호화한다.'}],roots:[root],resolvePath:p=>path.join(root,p),parsedOk:true});
const empty=CC.citationCheck({findings:[],roots:[root],parsedOk:true});
const cleared=CC.resolvedByNext({items:[{findingId:'finding1'}]},empty);
console.log(JSON.stringify({falseSemanticClaim:checked.items[0].kind,clearedByEmptyParsedFindings:cleared},null,2));
