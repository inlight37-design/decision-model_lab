const fs = require('fs');
const path = require('path');
const cp = require('child_process');
const base = path.join(__dirname, 'peek-engine-sandbox-' + Date.now());
const repo = path.join(__dirname, 'codex-peek');
fs.mkdirSync(base, {recursive:true});
process.env.CODEX_BRIDGE_HOME = path.join(base, 'bridge');
process.env.CODEX_HOME = path.join(base, 'codex');
process.env.CLAUDE_CONFIG_DIR = path.join(base, 'claude');
for (const p of [process.env.CODEX_BRIDGE_HOME, process.env.CODEX_HOME, process.env.CLAUDE_CONFIG_DIR]) fs.mkdirSync(p, {recursive:true});
const lib = require(path.join(repo, 'bridge', 'contract-lib.js'));
const br = require(path.join(repo, 'bridge', 'codex-bridge.js'));
const results = [];
const git = (ws,args) => {
  const r = cp.spawnSync('git',['-c','safe.directory=*','-C',ws,...args], {encoding:'utf8',windowsHide:true,timeout:10000});
  if (r.status !== 0) throw new Error(r.stderr);
  return r.stdout.trim();
};
const wait = ms => Atomics.wait(new Int32Array(new SharedArrayBuffer(4)),0,0,ms);
function setup(label, isGit) {
  const ws = path.join(base, label); fs.mkdirSync(ws,{recursive:true});
  const sid = label + '-session';
  if(isGit) { git(ws,['init','-q']); fs.writeFileSync(path.join(ws,'tracked.txt'),'initial'); git(ws,['add','.']); git(ws,['-c','user.name=Review test','-c','user.email=test@example.invalid','commit','-qm','initial']); }
  const cf=lib.contractFileFor(ws,'ko'); fs.mkdirSync(path.dirname(cf),{recursive:true});
  fs.writeFileSync(cf,JSON.stringify({workspace:ws,harnessMode:'codex-codex',codexVerifyMode:'always',codexImplementer:[],codexInjectMode:'off',scoutMode:'off'}));
  const lf=path.join(process.env.CODEX_BRIDGE_HOME,'links.json'); let links={byWorkspace:{},roleRevision:1};
  if(fs.existsSync(lf))links=JSON.parse(fs.readFileSync(lf,'utf8'));
  links.byWorkspace[lib.normWs(ws)]={workspace:ws,implementerSession:sid,implementerRevision:1,implementerEventAt:Date.now()-10000};
  fs.writeFileSync(lf,JSON.stringify(links));
  const tf=path.join(process.env.CODEX_BRIDGE_HOME,'codex-turns',sid+'.json'); fs.mkdirSync(path.dirname(tf),{recursive:true});
  fs.writeFileSync(tf,JSON.stringify({schema:'codex-turn-v1',turnId:'turn-1',workspace:ws,startedAt:Date.now()-9000,lastActionAt:0,modified:true,permissionMode:'default'}));
  const env={...process.env,CODEX_THREAD_ID:sid,CLAUDE_PROJECT_DIR:ws};
  const hook = (event, extra={}) => {const r=cp.spawnSync(process.execPath,[path.join(repo,'bridge','codex-hook.js')],{env,cwd:ws,input:JSON.stringify({hook_event_name:event,session_id:sid,turn_id:'turn-1',cwd:ws,permission_mode:'default',...extra}),encoding:'utf8',windowsHide:true,timeout:20000});return {exit:r.status,stdout:r.stdout,stderr:r.stderr};};
  function makeProof(answer) {
    const id='ask-'+label.replace(/[^a-z0-9]/g,'')+'-0011223344';
    const job={schema:'ask-job-v1',id,workspace:ws,harnessMode:'codex-codex',implementerSession:sid,implementerTurnId:'turn-1',implementerRevision:1,state:'succeeded',exitCode:0};
    const p=lib.writeDurableProofV2(ws,job,answer,'verifier-session'); if(!p.ok)throw new Error(JSON.stringify(p));
    job.finishedAt=new Date().toISOString(); const rr=lib.writeRecoveryReceipt(job);if(!rr.ok)throw new Error(JSON.stringify(rr));
    return JSON.parse(fs.readFileSync(p.file,'utf8'));
  }
  return {ws,sid,hook,makeProof,env};
}
{
  const s=setup('failverdict',false);
  const answer='Critical reproducible defect.\n[findings v1]\n'+JSON.stringify({tag:'blocker',title:'Reproducible failure',file:'code.js'})+'\n[findings end]\nVerdict: fail';
  const parsed=lib.parseFindingsBlock(answer);
  const machine=lib.judgeMachineVerdict(lib.extractVerdict(answer),parsed);
  // Invoke the real post-response findings and alert layer as well as proof construction.
  const proof=s.makeProof(answer);
  const layer=br.machineFindingsLayer ? br.machineFindingsLayer(answer,s.ws,'en','core','codex-codex','ask-review','cc:'+s.sid+':turn-1','') : null;
  br.flagVerdict(answer,s.ws,'verifier-session','always',layer&&layer.machine,null,'Fake test provider','ask-review',null);
  results.push({case:'explicit-fail-answer',machine,layerAvailable:!!layer,judgmentPending:lib.judgeRequiredPending(s.ws),proof,stop:s.hook('Stop')});
}
{
  const s=setup('nongit',false); const file=path.join(s.ws,'code.txt');fs.writeFileSync(file,'before');
  s.makeProof('Verdict: pass'); const before=s.hook('Stop'); wait(40);fs.writeFileSync(file,'AFTER_UNREVIEWED');
  s.hook('PostToolUse',{tool_name:'Bash'});
  results.push({case:'non-git-modified-after-proof',before,after:s.hook('Stop')});
}
{
  const s=setup('untracked',true); const dir=path.join(s.ws,'newcode');fs.mkdirSync(dir);const file=path.join(dir,'code.txt');fs.writeFileSync(file,'before');
  const m0=fs.statSync(dir).mtimeMs; wait(40);s.makeProof('Verdict: pass'); const before=s.hook('Stop');wait(40);fs.writeFileSync(file,'AFTER_UNREVIEWED');
  s.hook('PostToolUse',{tool_name:'Bash'});
  results.push({case:'git-untracked-child-modified-after-proof',gitStatus:git(s.ws,['status','--porcelain']),directoryMtimeUnchanged:m0===fs.statSync(dir).mtimeMs,before,after:s.hook('Stop')});
}
{
  const s=setup('trackedcontrol',true); const file=path.join(s.ws,'tracked.txt');
  s.makeProof('Verdict: pass'); const before=s.hook('Stop'); wait(80);fs.writeFileSync(file,'AFTER_UNREVIEWED');
  s.hook('PostToolUse',{tool_name:'Bash'});
  results.push({case:'positive-control-git-tracked-modified-after-proof',gitStatus:git(s.ws,['status','--porcelain']),before,after:s.hook('Stop')});
}
{
  const s=setup('fullfail',false);
  const cf=lib.contractFileFor(s.ws,'ko'); const c=JSON.parse(fs.readFileSync(cf)); c.verifierProvider='claude'; c.codexVerifyProfile='core'; fs.writeFileSync(cf,JSON.stringify(c));
  const answer='Reproducible correctness issue remains.\n[findings v1]\n'+JSON.stringify({tag:'blocker',title:'Confirmed reproducible failure',file:'code.js'})+'\n[findings end]\nVerdict: fail';
  const fake=path.join(base,'fake-provider.js');fs.writeFileSync(fake,"process.stdin.resume();process.stdin.on('end',()=>process.stdout.write(JSON.stringify({result:"+JSON.stringify(answer)+",is_error:false,session_id:'fake-verifier'})));\n");
  const env={...s.env,CODEX_BRIDGE_CLAUDE_BIN:fake,CODEX_BRIDGE_VERIFY_TIMEOUT_MIN:'1',CODEX_BRIDGE_JOB_WAIT_SLICE_MS:'0'};
  const invoke=args=>cp.spawnSync(process.execPath,[path.join(repo,'bridge','codex-bridge.js'),...args],{env,cwd:s.ws,encoding:'utf8',windowsHide:true,timeout:20000});
  const start=invoke(['ask-start','--allow-new','Review requested correctness criteria']);if(start.status!==0)throw new Error(start.stderr);
  const id=JSON.parse(start.stdout).jobId;const jf=path.join(process.env.CODEX_BRIDGE_HOME,'ask-jobs',id+'.json');let job;
  for(let i=0;i<80;i++){job=JSON.parse(fs.readFileSync(jf));if(['succeeded','failed'].includes(job.state))break;wait(100);}
  const got=invoke(['ask-wait',id]);
  results.push({case:'full-ask-start-worker-provider-ask-wait-stop-fail',jobState:job.state,jobExit:job.exitCode,waitExit:got.status,waitStdout:got.stdout,waitStderr:got.stderr,judgmentPending:lib.judgeRequiredPending(s.ws),stop:s.hook('Stop')});
}
console.log(JSON.stringify({base,results},null,2));
