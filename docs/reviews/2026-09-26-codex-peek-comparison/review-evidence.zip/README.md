# 독립 리뷰 검증 자료

기준일: 2026-09-26. 실제 provider 호출과 전역 설치를 하지 않은 소스/오프라인 검증입니다.

- peek-engine-repro.cjs: 가짜 Claude provider + 실제 bridge worker/후처리/Stop, freshness 반례와 tracked 양성 대조.
- peek-engine-repro-result.json: 이번 실행에서 캡처한 결과. 실패 답의 job 성공은 프로세스 성공 의미이며 모델 검토 통과와 다릅니다.
- citation-boundary-probe.cjs / citation-boundary-result.json: 식별자 위치 대조가 의미상 참을 뜻하지 않으며 빈 findings가 경보를 해소하는 경계.
- logs/: 통과로 보고한 Peek 15개 스크립트 로그 및 target 80개 선택 테스트 기록.
- notes/: 이번에 새로 작성한 분담별 상세 코드 분석. 기존 리뷰 문서가 아닙니다. 본문 보고서가 최종 종합 판단입니다.
- review-manifest.json: 두 기준 커밋과 환경.

## 재현 방법

Node.js와 Git이 있는 별도 빈 작업 폴더에 이 ZIP을 풉니다. 두 cjs 파일 바로 옆에 codex-peek 폴더가 있어야 합니다.

    git clone https://github.com/kimbyungsu/codex-peek.git codex-peek
    git -C codex-peek checkout --detach eb7cec1da0b13d2765eaab770c58d177024f423e
    node peek-engine-repro.cjs
    node citation-boundary-probe.cjs

스크립트는 자신이 위치한 폴더 아래 또는 OS 임시 폴더에 합성 자료를 만듭니다. 실제 계정의 Codex/Claude를 부르는 대신 가짜 provider를 사용합니다. 설치기를 실행할 필요는 없습니다. 결과의 workspace/시각/job ID는 매번 달라질 수 있습니다.

기존 Peek 검사는 codex-peek 폴더에서 `node tests/<이름>.test.js`로 실행한 것입니다. target의 정확한 선택 명령은 logs/target-selective-tests.txt에 있습니다. 전체 npm test/전체 Python discovery는 실행하지 않았습니다.

ledger-events 시험은 컴파일 산출물 부재로 시작하지 못했습니다. p8-enrich-run은 완료를 확인하지 못하고 이 리뷰가 시작한 시험 프로세스를 중단했습니다. 둘은 통과에 포함하지 않습니다. 모델 품질/벤치 수치/실제 Linux 격리/VS Code UI를 검증한 자료가 아닙니다.
