# decision-model_lab 현재 구현 독립 분석

기준 커밋: `435ba02f50d287f62dce7512a0ceae9b9c2f164b` (로컬 `git rev-parse HEAD` 확인). 코드 변경 없음. 이 보고서는 현재 `core/`, `app/`, `contracts/`, 직접 관련 테스트 및 허용된 README에서 분석했다. `docs/reviews`, `docs/research*`, 이전 FINAL_REVIEW/REVIEW_FIXES, 과거 검토 내용은 열지 않았다. README/코드 주석에 포함된 링크·과거 사건 언급은 현 코드의 배경으로만 노출됐으며 링크 원문은 따라가지 않았다. AGENTS의 과거 검토 참조 지시는 사용자의 독립 검토 요청에 따라 적용하지 않았다.

## 핵심 판정

우리 저장소는 단순한 두 CLI 연결기가 아니다. **같은 입력으로 독립 초안을 만들고, 공개 조건을 엄격히 지키며, 공개 뒤 합성하고, 호출·취소·종료 미확인을 원장으로 관리하는 로컬 의사결정 실험 시스템**이다. 현재 실행 경계는 bridge 편의 기능을 붙이기 전에 이미 상당히 구체적으로 구현됐다.

따라서 codex-peek에서 빌릴 대상은 기존 실행기를 통째로 대체하는 방법보다 **역할별 작업 요청, 결과/근거 구조화, 진행 상황의 제한적 관찰, 설정 진단과 사용자 경험**이다. 특히 자유로운 세션 이어쓰기·프로젝트 설정 상속·쓰기 실행·자동 재시도는 현재 독립성·예산 설계와 그대로 합칠 수 없다.

## 현재 제품과 실제 실행 범위

| 항목 | 소스에서 확인한 현재 동작 | 근거 |
|---|---|---|
| 제품 입력 | 질문, 참여자 목록, 최소 독립 정족수, 정책, 선택적 공통 자료 | `app/controller.py:309-363`, `app/server.py:200-222` |
| 기본 실행 | 명시적 실제 CLI 설정이 없으면 mock. 실제 옵션을 잘못 섞으면 조용한 mock 대체 없이 거절 | `app/server.py:330-362` |
| 실제 provider | Claude Code와 Codex 두 종류. Antigravity CLI spec은 core에 있지만 실제 executor에는 없음; UI에는 수동 원본 앱 참여가 있음 | `app/cli_executor.py:40`, `core/adapters.py:46-53`, `app/server.py:50-56` |
| 실제 OS | Linux/WSL. Windows runner의 Job Object 구현과 Windows mock 경로가 있어도 실제 provider 실행이 Windows 지원이라는 뜻은 아님 | `app/server.py:342-345`, `app/readiness.py:29-31`, `app/controller.py:177-212` |
| 역할 | 실제 adapters의 `ROLES = (DISCUSSANT,)`. 쓰기 구현자, 자동 패치 적용, reviewer→fixer 반복 루프가 아님 | `core/adapters.py:34-35,204-248` |
| 첫 초안 | 참여자가 다른 초안을 보지 않고 결론·근거·반전 조건 작성. 자동 재호출 없음 | `app/controller.py:56-57,470-475` |
| 공개 뒤 합성 | mock 발췌 대조 또는 명시적 모델 합성. 같은 초안에 다른 provider 합성을 순차 비교 가능 | `app/controller.py:746-855` |
| 사용 경로 | 로컬 HTTP UI 및 headless CLI가 같은 `live_setup`, `Controller`, `decision_report` 경로를 공유 | `app/run.py:93-184`, `app/server.py:330-370` |
| 형식상 proof | `contracts/v0.2/pilot.schema.json`은 `offline_design_fixture`/`synthetic_proof_not_execution`, backend=`unconfigured`. 실제 소스 패치 검증 파이프라인이 아님 | `contracts/v0.2/README.md:3,11-21`; schema는 한 줄 파일 |

실제 코드에서 `TaskSpec`, `DecisionAdvice`, `WorkerResult`, `base_commit`, `bounded_patch`, `proof`를 처리하는 runtime 경로는 `core/`, `app/` 검색에서 찾지 못했다. 계약 설계가 있다는 사실을 실행 구현이 완료됐다고 쓰면 안 된다. 반대로 실제 모델 합성, common source, cancellation, persistence, quota 조회는 현 소스에 구현되어 있으므로 이를 새 제안으로 포장하면 중복이다.

특히 기존 `contracts/v0.1.schema.json:10-31`의 task 계약에는 `project_id`, `task_id`, `state_version`, `base_commit`, `write_paths`, `acceptance_ids`, `context_ids`, budget가 이미 있고, `:62-81`의 worker_result에는 `attempt_id`, `artifact_ids`, `limitations`, usage가 있다. 따라서 아래 typed envelope 제안은 **새 설계 개념을 외부에서 들여오는 것보다 기존 계약을 현재 controller의 실제 실행에 연결하고 review evidence를 보강하는 작업**으로 표현하는 것이 정확하다. `contracts/README.md:3-5,16-18`도 이 계약은 설계 예시이고 resolver/lease/실제 실행 증거를 제공하지 않는다고 명시한다.

## 실제 실행 경로와 기존 강점

### 1. 실행 전 계획과 관측이 연결되어 있다

`Executor.plan()`은 불변 `Plan`을 한 번 만들고 controller가 그 기록을 attempt ID와 함께 저장한 후 같은 객체를 `run()`에 전달한다. 계획은 최종 argv, stdin digest/크기, sandbox, 요청 모델, stderr marker, 실행 종류와 revision을 가진다. `contract.template()`는 prompt/model/home 같은 매 실행 값은 역할 이름으로 바꾸되 권한·출력 모드·설정·mount 의미는 보존하고 revision hash를 만든다. argv를 바꾼 관측을 다른 실제 실행 계획에 무조건 재사용하지 않는 구조다.

- `core/contract.py:35-54,56-96`
- `app/controller.py:489-516,540-550`
- `app/cli_executor.py:118-170`
- 검증 테스트: `tests/test_app_contract.py:36-60`, `tests/test_core_contract.py:83-133`

준비 조회는 단지 CLI가 설치됐는지 확인하는 기능이 아니다. 설치 버전·구독 인증·전송·문맥·권한의 다섯 관측, 관측일, 30일 freshness, 현재 revision과 현재 설치판을 대조하고 기기 등록도 검사한다. 준비 조회 자체는 모델/CLI 프로세스를 실행하지 않으며 실행 직전에도 재검사한다. 단, evidence 문자열의 진위 자체를 코드가 증명하는 것은 아니다.

- `core/eligibility.py:32-38,66-141`
- `app/readiness.py:15-61`
- `app/cli_executor.py:90-116,152-169`

### 2. 이미 OS 파일 격리와 문맥 제한이 구체적이다

Linux/WSL 실행은 bubblewrap의 `--unshare-all --share-net --die-with-parent --new-session`을 쓴다. 입력과 실행 파일은 ro, work와 해당 CLI 인증/설정 폴더는 rw, HOME/tmp는 빈 tmpfs. 원장 경로와 겹치는 mount는 `never`로 거절하고 mount 순서/권한 확대/realpath도 검사한다.

- `core/isolation.py:68-77,140-182,185-220`
- CLI mount: `core/isolation.py:80-113`
- controller 데이터 폴더 제외 연결: `app/server.py:346-350`

CLI 문맥 제한도 별도로 있다. Claude는 `--restricted --safe-mode`, `dontAsk`, 세션 미보존, strict MCP 및 Read 도구만. Codex는 ephemeral, user config/rules 무시, apps/plugins off, project docs off, 모델의 명령에 `~/.codex` 읽기 금지. 전역 AGENTS 파일이 존재하면 계획/실행 전에 거절한다. Codex 실행 파일을 `.codex` 밖의 `/opt/dml-codex`로 옮겨 보이는 것도 그 권한 경계를 유지하려는 구현이다.

- `core/adapters.py:165-186,237-265`
- `app/cli_executor.py:90-97,128-150`
- `core/isolation.py:100-113`

네트워크는 공유하며 CPU/메모리 제한은 없다. CLI 자체는 인증 갱신을 위해 자기 설정 폴더에 접근한다. 점검과 실행 사이 호스트 파일 변경 경쟁도 차단하지 않는다. 따라서 모든 외부 효과/데이터 유출을 막는 완전 격리라고 표현하면 안 된다. `--share-net`의 localhost 접근을 막기 위해 controller API가 별도 토큰을 요구한다.

- 제한: `core/isolation.py:26-32,214`
- HTTP Host/Origin/token: `app/server.py:114-128`

### 3. 완료 판정은 exit code나 답 텍스트보다 엄격하다

runner는 `shell=False`, argv 목록, 절대 실행 파일을 사용하고 batch 파일을 거절한다. 타임아웃/취소 시 프로세스 tree 정리를 시도하고 stdin 완전 전달, stdout/stderr 상한, pipe 잔존을 기록한다. `tree_confirmed_empty`는 추적 단위가 비었다는 것과 구별한다. plain POSIX process group은 탈출 자손까지 종료했다고 인정하지 않는다.

- `core/runner.py:77-120,320-440`
- `core/isolation.py:223-243`

adapter는 Claude의 result/error/초기 permission surface, Codex `turn.completed`와 stderr policy rejection, 출력 잘림 및 형식을 해석한다. controller는 별도로 **전체 tree 종료 확인 + adapter 의미 성공 + stdin complete + 비어 있지 않은 답 + 명시적 모델 불일치 없음**을 모두 요구한다. 보고 모델이 없다는 사실을 요청 모델을 실제 썼다는 증거로 채우지 않는다.

- `core/adapters.py:315-345,416-480`
- `app/controller.py:252-274`

이 경계를 bridge에서 흔한 “마지막 assistant 텍스트가 있으면 성공” 판정으로 대체할 이유가 없다.

### 4. blind barrier는 UI뿐 아니라 원장·노출 경계에 있다

원장에 sealed draft와 digest를 저장하고 참여자는 원장에 mount되지 않는다. 참여자가 아직 답을 쓰는 동안 UI에는 고정된 상태 필드만 내보낸다. draft 내용/길이/hash, 토큰 수, 소요 시간은 공개 전 숨기며 자유형 진단도 모두 settle한 뒤 노출한다. Claude 계정 사용 비율 또한 초안 길이 추측에 쓰일 수 있어 봉인 중인 결과는 내보내지 않는다.

- `app/store.py:1-9,45-60`
- `app/controller.py:119-123,442-467,858-898`

참여자 rows가 상태의 진실 원천이고 gate는 파생값이다. 공개는 모든 참여자가 settle하고 정책상 quorum이 충족된 뒤 같은 DB transaction에서 바뀐다. 빠진 참여자가 있으면 축소를 명시적으로 승인해야 하며 그 승인도 최소 quorum을 무력화하지 않는다. 수동 앱 참여/문맥 미확인은 별도 정책 없이는 독립 quorum에 세지 않는다.

- `app/state.py:22-24,54-88`
- `app/controller.py:617-657,659-719`

codex-peek식 raw JSONL 진행 로그를 UI/MCP client에 그대로 보내면 이 기존 경계를 깰 수 있다. 관찰성 도입은 채널 권한과 공개 단계에 맞춘 allowlist projection이 선행해야 한다.

### 5. 지속성·호출 예산·취소/재시작 처리가 이미 있다

SQLite schema 7은 runs/participants/drafts/events/sources/live_budget을 저장한다. events는 append-only, 현재 상태 변경과 같은 transaction이다. 파일 잠금으로 원장 하나당 controller 하나만 허용하고 새 schema를 구버전 코드로 열면 거절한다.

- `app/store.py:23-61,73-114,116-173,240-284`

실제 호출은 시작 전에 전체 및 provider별 cap 안에서 **예약을 먼저 저장**한다. cap은 처음 바인딩 후 재시작으로 증액/삭제할 수 없다. 실패·취소·재시작으로 예약을 환불하지 않는다. unknown attempt는 병렬 slot과 unsettled 상한을 계속 차지한다. 예약과 프로세스 실제 시작은 구분되어, 예약 후 정책이 철회될 경우 예약만 남을 수 있다.

- `app/store.py:186-229`
- `app/controller.py:417-440,502-520`

취소는 DB에 먼저 저장한 뒤 worker signal을 보낸다. 뒤늦게 성공한 답도 취소된 실행에 수용하지 않는다. restart 시 running은 unknown, queued는 명시적 resume 전 정지한다. 종료 확인 acknowledgement는 slot만 풀고 환불/답 수용/재시도를 하지 않는다. 모델 합성도 동일한 slot/cap과 persistent unknown 규칙을 쓴다.

- `app/controller.py:594-605,636-657,721-744,760-855,1009-1039`
- `app/state.py:91-119`

### 6. 공통 자료와 합성은 이미 근거 추적의 토대가 있다

공통 자료는 이름·내용·byte size·sha256을 원장에 고정하고 질문 digest가 그 manifest를 묶는다. 파일 20개, 파일당 256 KiB, 전체 1 MiB. 각 시도 전에 제공 사본의 목록·크기·hash, 원래 prompt와 folder가 여전히 일치하는지 검사한다. 실행 중 호스트 변경 race까지 차단하는 것은 아니다.

- `app/controller.py:58-63,88-117,337-361,375-407`

원문 report는 input/draft hash를 재검증하고 source manifest, 독립성, 실행 provenance, 모델/usage observation을 포함한다. 합성에는 원문 공개 후만 접근할 수 있다. 합성자에게 provider명을 직접 붙이지 않고 D1/D2를 실행별로 결정적 재배열하며, 대응표를 보존한다. claims/disagreements/strongest_counterexample/unresolved/recommendation을 구조화한다. 인용은 정확한 substring 위치와 draft digest로 대조한다. 문자열 일치 ≠ 의미상 지지 ≠ 사실 검증이며 모든 disposition은 unresolved다. 실패한 합성 원문은 65,536자까지만 보존하고 전체 digest/길이를 남긴다.

- `app/report.py:35-78,82-93`
- `app/synthesis.py:29-39,46-84,138-148,203-272,275-300`

단순 다수결, self-reported confidence, citation marker만으로 합성 결과를 PASS로 승격시키는 기능은 가져오면 안 된다. 현재 구현보다 증거 기준이 약해질 수 있다.

## 빌릴 만한 기능을 붙일 정확한 지점

아래는 codex-peek 구현 자체에 대한 판정이 아니라, 우리 코드의 빈틈에서 도출한 도입 조건과 위치다. 상대 저장소 검증 결과와 결합해야 한다.

| 후보 | 현재 빈틈/필요 | 우리 코드에 붙일 위치 | 지켜야 할 조건 |
|---|---|---|---|
| 역할별 요청 envelope | 질문 자유 텍스트와 source 파일만 있어 review 대상/범위/완료 조건을 기계적으로 비교하기 어려움 | `ParticipantSpec` 및 `create_run` (`app/controller.py:152-160,309-363`), `runs` schema (`app/store.py:33-40`) | `task_kind`, 대상 commit/tree/source digest, 허용 범위, acceptance criteria, proof 요구를 고정 입력 hash에 포함. reviewer/implementer 역할을 실제 권한 구현 전에 이름만 추가하지 말 것 |
| 증거를 요구하는 review 결과 | 현재 synthesis claim은 statement와 draft quote에 한정. 원래 파일/line/테스트 실행을 직접 검증하지 않음 | `app/synthesis.py:203-272`, `app/report.py:35-78`에 버전된 별도 review report를 추가 | `finding_id`, target revision, path/range, severity, claim, evidence kind/ref/digest, reproduction/check status, counterevidence, unresolved를 분리. 인용 파싱 성공과 실제 검사 통과를 다른 칸에 기록 |
| 요청된 evidence와 실제 evidence의 적합성 검사 | current source snapshot hash는 내용 무결성이지만 그 자료가 이 claim을 뒷받침하는지, 필수 증거가 갖춰졌는지는 별도 없음 | source manifest (`app/controller.py:88-117,337-361`), synthesis parser (`app/synthesis.py:215-255`) | 파일 존재/범위/digest는 deterministic resolver로; 의미 검토 결과는 판정자·방법·한계와 함께. 없는 quote를 지우지 않는 현재 동작 유지 |
| 시작/상태/결과 분리 adapter | UI 및 headless는 있으나 외부 AI host가 Controller를 부르는 tool facade는 없음 | `app/server.py:166-188,192-265` 같은 기존 명령 경계 위의 얇은 client/MCP 계층 | 독립 별도 job DB를 만들지 말고 run_id/attempt_id와 기존 원장 사용. tool timeout을 worker success/failure로 해석하지 말 것. blind pre-reveal projection 그대로 적용 |
| 제한된 진행 이벤트 | 현재 UI는 1초마다 전체 state/quota를 읽고 controller view는 모든 run을 조회 | `app/static/index.html:1144-1153,1192`; `app/controller.py:865-936`; `app/store.py:275-284` | 먼저 서버 commit 후 sequenced 상태 이벤트만 발행. reconnect cursor/중복 처리. draft/tool text/token량 같은 누출은 공개 뒤만. raw stdout를 실시간 중계하는 기능은 그대로 이식 금지 |
| review 템플릿 | 현재 독립 초안 prompt는 결론·근거·반전 조건의 단일 템플릿 | `app/controller.py:56-60`, `app/synthesis.py:29-39` | 작업별 체크리스트·대상 범위·untrusted 자료 지침을 versioned prompt로 관리하고 hash에 결합. 템플릿 변경 후 conformance/평가를 다시 실행 |
| 재현 가능한 비교 실행 | CLI가 이미 동일 초안을 다른 합성자로 비교 가능. 자동 채점/품질 개선 근거는 runtime에 없음 | `app/run.py:139-184`, `app/report.py:82-93` | 같은 예산의 단독 모델/현재 방식/도입 기능을 동일 자료로 비교. 오류/누락/unsupported claim/호출/지연을 함께 측정. 테스트 통과를 품질 개선으로 표현하지 말 것 |

추천 우선순위는 **P1: task/evidence envelope 및 review report → P1: 얇은 host integration/진행 UX → P2: 필요한 경우 event stream → 별도 검증 뒤 쓰기 역할**이다. 현재 이용량에서 전체 state polling이 병목이라는 측정은 없으므로 SSE/WebSocket을 먼저 넣을 근거는 부족하다. 사용자에게 유용한 더 좋은 요청과 검토 결과를 만드는 일이 transport 개편보다 선행한다.

## 그대로 가져오지 않을 것

1. 오래 사는 Codex/Claude 세션을 독립 초안 사이에서 공유: 현재 `--ephemeral`, `--no-session-persistence`와 blind first-draft 목적에 반함. post-reveal 대화 기능이 필요하면 별도 phase/session 계보와 non-independent 표기를 설계한다.
2. host의 MCP/apps/plugins/AGENTS/CLAUDE 문맥 무조건 상속: 현재 계획 revision과 conformance 관측의 의미를 바꾼다.
3. permissive sandbox/자동 승인/쓰기 권한을 bridge 편의 옵션으로 열기: 현재 역할은 read-only discussant뿐. worktree 격리만으로 현재 OS boundary와 동등하지 않다.
4. 일시적 네트워크 오류/format error/timeout에 자동 retry: 이미 쓴 호출과 종료 미확인을 원장 및 slot에 반영해야 한다. 새 attempt reservation 없는 재호출은 금지.
5. 다른 DB/job store를 원장 옆에 두고 상태를 서로 복사: 단일 authority와 commit 원자성을 잃을 수 있다.
6. HTTP 전송 성공, exit 0, 답 존재, 여러 모델의 동의, citation 존재를 최종 PASS로 취급: 현재 acceptance/factual-check 분리보다 약하다.

## 이번 독립 검증

환경: Windows, Python 3.12.10. targeted offline 테스트 **80개 중 79개 통과, 1개 OS 조건 skip**, 실패/오류 0, 10.804초, exit 0. 실제 provider 모델 호출, 계정 query, CLI 설치, global install은 하지 않았다. source 변경 없음 (`git status --short` 비어 있음).

실행 대상: `test_app_contract`, `test_core_contract.RevisionTests`, `test_app_cancel`, `test_app_state`, `test_synthesis_lifecycle`, `test_sources`, `test_store_policy`, `test_headless_run`, `test_model_synthesis`, `test_core_eligibility.EligibilityTests`.

skip: `test_sources.RevisionTests.test_a_source_folder_keeps_the_one_input_revision_whatever_its_path_or_content` — `uses Linux fake-install symlinks`.

선택한 클래스의 입력은 synthetic/temp fixtures다. 테스트 의존 모듈에 과거 manifest 경로 상수가 있지만 해당 과거 파일을 읽는 RecordTests/LiveRecordTests 등은 실행하지 않았다. 전체 discover는 역사 문서/관측 기록까지 읽는 검사가 있으므로 이번 요청에서는 피했다. Linux bwrap의 실제 동작, 실제 provider 인증/모델 응답, 최신 설치 환경, 모델 품질과 실제 절감률은 재검증하지 않았다.

테스트 결과는 실행 계약/상태 전이/합성 인용 파서와 mock end-to-end의 국소 회귀 근거다. 기존 실환경 관측이나 현장 품질의 독립 재현 증거가 아니다.
