# codex-peek runtime / verification independent analysis

검토 기준: commit `eb7cec1da0b13d2765eaab770c58d177024f423e`, package version 0.1.103. 기존 리뷰나 리뷰 요약 문서는 열지 않았다. 원본 코드, 원본 테스트, package.json, SECURITY.md를 분석 데이터로 읽었다. 전역 설치·실 모델·실 로그인 세션 호출은 하지 않았다.

## 판단

가장 가치 있는 부분은 “다른 모델에게 검토를 요청한다” 자체보다, **검토 요청과 응답이 어느 작업·세션·턴·역할 세대에 귀속되는지 관리하고, 장애·중복 호출·미회수를 별도 상태로 남기는 운영 장치**다. 우리 시스템에는 이 결속 설계와 명시적 상태 분리를 참고할 가치가 크다. 반면 이 저장소의 `proof`/`succeeded`를 품질 통과 인증으로 그대로 이식하면 안 된다. 실제 코드는 실행 성공과 검토 판정 성공이 분리되어 있으며, 일부 문구가 이 구분보다 강한 “통과 증명” 표현을 사용한다.

## 실제 구성과 흐름

| 층 | 책임 | 원본 근거 |
|---|---|---|
| IDE extension | 대시보드/세션 선택/설정/상태와 통계 표시, 배포된 bridge 런타임 관리 | `package.json:1-92`, `src/extension.ts` |
| Claude lifecycle | 사용자 턴 앵커, 계약·지시 주입, Stop 검증 요구 | `bridge/contract-inject.js:9,193-203`, `bridge/session-start.js`, `bridge/verify-guard.js:225-288` |
| Codex lifecycle | 구현 세션 고정, 턴 추적, Pre/PostToolUse와 Stop | `bridge/codex-hook.js:627-693`, 특히 `519-576` |
| bridge CLI | 세션 연결, 검토 요청 작성, provider 호출, 결과 정리 | `bridge/codex-bridge.js:4672-5081` |
| durable job | ask-start → detached worker → ask-wait, 도구창 수명과 검토 수명 분리 | `bridge/codex-bridge.js:3100-3267`, `bridge/ask-job-worker.js:199-275` |
| protocol/state library | 계약, 역할, proof/receipt, 캠페인 예산, findings/판단/제약/규약 전달 | `bridge/contract-lib.js` |
| evidence/advisory | 인용 실존·읽은 흔적·재확인, 지적/판정/경보·통계 | `bridge/codex-bridge.js:4837-4885`, `bridge/evidence-challenge.js` |

표준 흐름은 ①훅이 구현 턴과 계약을 잡음 → ②ask-start가 모드·프로필·provider·언어·캠페인·재판단 문안·구현 세션/턴/역할 revision을 동결 → ③workspace 단위 단일 작업 선점 → ④worker가 실제 provider 호출 → ⑤proof, evidence, findings, verdict, 출력 저장 → ⑥ask-wait가 결과 회수 및 receipt 작성 → ⑦Stop가 현재 턴에 결속된 증거를 확인하는 형태다.

모드와 provider를 구분해야 한다. `harnessMode=claude-codex|codex-codex`는 구현 lifecycle/역할 모드이고, verifier provider는 별도 설정이다. Claude verifier도 있으며 `-p --output-format json` 무상태 호출을 지원한다(`codex-bridge.js:2739-2771,4893` 이후). therefore “Claude 대 Codex 두 프로그램 사이만 연결하는 단순 UI”보다 범위가 넓다.

## 가져올 가치가 큰 설계

### 1. 실행·판정·회수·최신성을 서로 다른 사실로 취급

`ask-job`은 호출 수명, proof는 응답 발생과 귀속, receipt는 구현자가 공식 회수 경로를 밟았음, verdict/findings는 내용 판정을 담당한다. 아직 최종 통과 gate의 결합은 아래 한계가 있지만, 이 사실들을 다른 데이터로 기록하는 방향은 좋은 출발점이다.

- C-C job 생성 시 `(implementerSession, implementerTurnId, implementerRevision)` 동결: `contract-lib.js:1495-1516`, `codex-bridge.js:3140-3165`.
- proof v2는 job snapshot과 현재 역할·턴을 기록 직전 같은 role lock 아래 재검사: `contract-lib.js:1585-1620`.
- receipt는 job/proof의 필드를 복사하며 `ts=job.finishedAt`로 결정론적 바이트를 만들어 중복 회수를 멱등화: `contract-lib.js:1622-1661`.
- Stop는 세션·턴·workspace·역할 revision·proof raw SHA256·receipt 연결과 HEAD를 검사: `contract-lib.js:1663-1695`.
- 같은 턴 성공 결과를 회수하기 전에 후속 job이 단일 proof 슬롯을 덮지 못하게 함: `codex-bridge.js:3004-3025,3149-3153`.

우리 쪽에 맞추면 `analysis_run_id / input_snapshot_id / policy_version / producer_version / result_digest / acknowledged_by` 같은 독립 필드로 변환하는 편이 좋다. CLI 세션 id와 wall-clock timestamp만 복사하는 이식은 피할 것.

### 2. 장애 시 재전송보다 상태 확인

- ask-start의 기존 active/job 확인과 queued 생성이 같은 workspace lock 안에서 일어남: `codex-bridge.js:3128-3139`.
- prompt 해시 중복 방지 전에 workspace 전체 ask를 선점해 문구만 바꾼 중복 호출도 억제: `codex-bridge.js:4762-4804`.
- 서로 다른 workspace가 같은 verifier 세션을 resume하는 경우를 별도 session lease로 막음. 임대 token이 맞아야 해제: `contract-lib.js:2470-2539`.
- owner 종료만으로 재시작하지 않고 child 생존 여부까지 고려. child 정보가 없으면 자동 회수하지 않음: `contract-lib.js:2484-2488,2511-2521`.
- 작업 id 해결 실패 후 세션을 무한 생성하지 않고 `autoNewFailed` 상태를 남김: `codex-bridge.js:5015-5023,5050-5059,5073-5080`.

우리 쪽 batch/analysis job에 적합한 개념은 idempotency key, one-active-run constraint, lease ownership token, resumable result retrieval이다. 파일 lock과 PID 자체는 단일 컴퓨터 구현이라 서버/다중 노드에 그대로 복사하면 안 된다.

### 3. 내구 작업과 진단의 분리

ask-start는 detached worker를 만들고 바로 jobId를 반환한다(`codex-bridge.js:3205-3221`). worker는 별도 stdout/stderr 파일, deadline, exit status를 보관한다(`ask-job-worker.js:219-275`). 핵심 응답이 이미 proof/output에 결속되어 완성됐는데 후속 evidence challenge가 실패한 경우, primary checkpoint를 검증하여 주 작업 결과를 복구하고 challenge exit를 별도 보존한다(`ask-job-worker.js:30-96,251-264`).

“분석 본체는 성공했으나 부가 설명 생성/알림은 실패” 같은 상태를 파괴하지 않는 데 유용하다. 다만 현재 job 성공은 모델 내용의 pass를 뜻하지 않는다.

### 4. 비용/회차를 모델 호출 직전 예약

캠페인 budget은 모델 호출 전 잠금 아래 count를 예약하고, budget 값을 캠페인에 고정한다. 프로젝트/세션 교대 후 재개할 때 history에서 회차와 환급 count를 복원한다(`contract-lib.js:773-825`). 응답이 한 글자도 없는 실패에 한해 회차를 되돌리되 최대 2회로 제한한다(`828-833`, `codex-bridge.js:4962-4974`). 요청 형식/계약 길이/지적 처분 관문은 예약 전에 검사한다(`codex-bridge.js:4807-4819`).

“호출 불가능한 요청으로 예산을 먼저 태움”, “재시도로 같은 일을 중복 계산”, “보고 화면의 반복 횟수와 실제 provider 호출 횟수 혼동”을 줄이는 데 도움이 된다.

### 5. 규약 전달 generation과 변경 감지

과거 설명처럼 모든 긴 정적 지침을 매번 무조건 다시 보내는 방식은 아니다. 정적 성분별 지문을 계산하여 처음/세션 reset/문안 generation 변경에는 전문을 보내고 그 외는 전달 시점·generation 포인터를 보낸다(`contract-lib.js:6097-6140`). 검증의 시작 시점 문안을 job에 동결해 기다리는 사이 UI 설정 변경이 후처리 문안을 바꾸지 않게 한다(`codex-bridge.js:3194-3205`).

우리 쪽에는 분석 당시 적용한 rubric/policy/schema 버전을 결과와 함께 저장하는 원칙이 유용하다. 단 “전달 기록”은 모델이 이해했거나 따랐다는 증거가 아니다.

## 검증으로 확인한 중요한 한계

### A. `proof`와 `succeeded`는 판정 pass 증명이 아니다 — 전체 체인 재현

**구체적 조건:** C-C lifecycle, core profile, 승인 envelope/archive 없음, verifierProvider=claude, 실제 provider 대신 성공 JSON을 출력하는 로컬 fixture. fixture 응답에는 정상 findings v1 blocker 1건과 마지막 `Verdict: fail`을 넣었다. 실 ask-start → 실 worker → 실 ask/후처리 → 실 ask-wait → 실 Codex Stop를 실행했다.

**실측:** job.state=`succeeded`, job.exitCode=0, ask-wait exit=0. stdout은 `Verdict: fail`과 “blocker를 고치고 재검증하라” 지시를 정확하게 보존했다. `judgeRequiredPending=[]`. 그런데 Stop stdout은 빈 문자열(차단 없음)이었다.

**원인:**

- `codex-bridge.js:4825-4830`: proof를 내용 판정보다 먼저 기록한다.
- `4845-4847`: machineFindingsLayer/flagVerdict는 그 후다.
- `contract-lib.js:1545-1559`: proof schema에는 verdict, findings digest, answer digest가 없다. success/exit/answerChars를 검사한다.
- `ask-job-worker.js:268-274`: 프로세스 exit=0이면 job succeeded.
- `codex-hook.js:570-576`: durableProofGate가 true면 별도 residual/judgment/rule-check만 확인 후 done.
- `contract-lib.js:1665-1695`: gate는 판정과 열린 blocker를 직접 조회하지 않는다.
- `codex-bridge.js:2258-2277`: fail은 error severity 경보로 가시화한다. 이 경보는 일반 Stop 차단 근거가 아니다.

**한정:** 모든 실패에서 종료가 허용된다고 주장하면 안 된다. scope-demoted로 남은 blocker가 모두 제거된 경우, 반복 dispute, postflight 판독 문제 등은 별도 판단 marker/hold를 만들어 차단한다(`codex-bridge.js:4517-4526,4549-4557,4826-4829,4887-4889`). 승인 envelope가 없는 정상 설정에서 “일반 유효 fail”이 gate를 통과함을 확인한 것이다. 실제 모델 정확도를 평가한 테스트는 아니다.

**이식 방향:** `execution_succeeded`, `review_verdict`, `artifact_current`, `findings_resolved`, `result_retrieved`를 별도 상태로 유지하고, 최종 승인 조건이 무엇인지 함수 하나에서 명시적으로 AND 결합할 것. 분석품질 판정과 프로세스 성공을 동일한 초록 상태로 표시하지 말 것.

### B. 최종 작업물 최신성이 내용 해시가 아니라 mtime 근사 — 두 누락과 양성 대조 재현

동일 C-C hook 입력 및 proof/receipt 상태를 구성하고, proof 후 파일 내용을 바꾼 다음 실제 PostToolUse(Bash)와 실제 Stop를 실행했다.

| 사례 | 결과 |
|---|---|
| Git의 추적 파일 `tracked.txt` 수정 | Stop BLOCK, `proof-stale` — 양성 대조 정상 |
| non-git 폴더의 파일 수정 | Stop 통과 |
| Git의 untracked 디렉터리 `newcode/` 안 이미 존재한 `code.txt` 내용 수정 | Stop 통과 |

untracked 사례에서는 `git status --porcelain`이 `?? newcode/`만 반환했고, 파일 내용을 바꿔도 디렉터리 mtime은 변하지 않음을 같이 기록했다.

**원인:** `codex-hook.js:172-186`은 git status 결과의 경로를 stat하고, non-git/git 실패면 0을 반환한다. 기본 untracked collapsed-directory 출력을 재귀 탐색하지 않는다. `567-571`은 회수 도구가 proof를 자기무효화하는 문제를 막기 위해 `lastActionAt`을 최신성 계산에서 제외하여 `max(turn.startedAt, gitTs)`만 쓴다. HEAD 결속(`contract-lib.js:1679-1682`)은 커밋 변화에는 도움되지만 untracked 파일/비Git 내용 변화를 담지 못한다.

Claude `verify-guard.js:31-80`에도 기본 `--porcelain` + stat 경로 근사가 있으나 Claude 전체 Stop 흐름으로 동일 사례를 추가 실증하지는 않았다. 따라서 재현 결과는 C-C 한정으로 쓰는 것이 정확하다.

**이식 방향:** `-uall`은 untracked directory collapse 누락만 해결한다. mtime 보존 복사, 검사 도중 변경, hash가 담는 input 범위, ignored data 포함 여부, 삭제/이름변경, non-git 입력은 별개다. 우리 쪽은 명시적 입력/산출물 manifest에 content digest를 저장하고 검증 시작/완료/최종 사용 직전에 대조하는 모델이 낫다. Git이면 commit OID + dirty tracked/untracked content snapshot, 데이터 분석이면 dataset/config/rule/model version으로 대체.

### C. Stop gate는 무조건적인 강제가 아니다

Claude와 Codex 모두 같은 진행 상태의 반복 종료 차단 최대 3회 후 작업을 끝내게 하는 안전밸브가 있다(`verify-guard.js:15-16,105-120,338-375`; `codex-hook.js:45,598-616`). 경보/phase incomplete를 남겨 무한 정지를 피하는 정책이다. 이는 타당한 운영 선택일 수 있으나 보안 gate/출시 승인 gate를 대체하지 못한다. 우리 시스템에는 이 전략을 UI/agent 루프의 “계속 막지 말고 미완료로 반환”에 쓸 수 있고, 실제 승인 상태는 미승인 그대로 유지해야 한다.

### D. 권한 격리나 악성 조작 방어 경계가 아님

- 로컬 사용자 권한으로 JSON/JSONL 파일을 쓰며 proof도 같은 계정이 변경할 수 있다. SHA256 receipt는 우발적 다른 proof 사용·바이트 변화 탐지에 도움되지만 외부 신뢰 주체의 서명이 아니다.
- PreToolUse guard는 명령 문자열 regex다. `codex-guard.js:19-26`은 bridge 문자열을 포함하면 직접 호출 차단에서 제외한다. 의도적으로 우회 가능한 협력적 정책층이다. `SECURITY.md`도 직접 호출 guard와 계약 텍스트가 sandbox가 아니라고 명시한다.
- `runCodex` 호출은 사용자가 설치한 실행파일/설정에 의존한다(`codex-bridge.js:2774-2789,4961,5044`). 새 독립 권한 경계를 만들어 주는 시스템이라고 읽으면 안 된다.
- Codex rollout·Claude transcript·hook event schema·내부 세션 metadata와 강하게 연결되어 있다. `codex-hook.js:627-667`, `codex-bridge.js:568-668,1575-1659,2075-2117`. 앱과 CLI 버전 변경을 견디는 adapter contract tests가 필요하다.

## 운영 부담과 이식 시 주의

1. 상태가 수많은 JSON/JSONL 디렉터리에 분산되어 있고 `contract-lib.js` 7천여 줄, `codex-bridge.js` 5천여 줄에 검증·기억·budget·UI 전달 의미가 집중되어 있다. 기능 전체를 fork해서 붙이는 비용이 크다. 원자 rename/lock/token 개념을 우리 저장 계층의 transaction/unique key/CAS로 옮기는 편이 낫다.
2. 파일 손상 시 fail-closed 경로가 존재하지만 범위는 균일하지 않다. 예: 손상 job 파일의 workspace를 식별할 수 없으면 모든 새 workspace job을 차단한다(`codex-bridge.js:3135-3139`). 안정성을 위해 가용성을 희생한 선택이며 단일 사용자 도구에 더 잘 맞는다.
3. “proof accepted”, “worker succeeded”, “verdict fail”, “phase done”, “error alert visible”가 동시에 가능한 상태다. 이 프로젝트를 도입하든 아이디어만 취하든 UI 용어부터 명확히 해야 한다.
4. 기본 “모든 작업 자동 검증”보다 어떤 사건이 재검증을 필요로 하는지, 어느 입력의 어떤 판정이 최종 승인인지 먼저 정의해야 한다. 시스템 속성은 인수조건·근거 artifact·생성 provenance를 중심으로 설계해야 한다.

## 실행 검증 기록

직접 실행한 기존 테스트(실 provider 없음):

- `tests/verify-guard.test.js`: 57 pass / 0 fail — `work/engine-test-verify-guard.log`
- `tests/verify-lastturn.test.js`: 9 pass / 0 fail — `work/engine-test-verify-lastturn.log`
- `tests/verify-sequential.test.js`: 183 pass / 0 fail — `work/engine-test-verify-sequential.log`
- `tests/session-lease.test.js`: 37 pass / 0 fail — `work/engine-test-session-lease.log`
- `tests/codex-verify-recovery.test.js`: script success — `work/engine-test-codex-verify-recovery.log`

개별 tests는 자체 임시 bridge dirs/fixtures로 격리한다. 초기 테스트 runner의 추가 바깥 env 설정은 PowerShell PathInfo.Parent 오류로 적용되지 않았으나 tests 자체의 temp 격리가 동작했고, 분석에 사용한 명시 재현 스크립트는 CODEX_BRIDGE_HOME, CODEX_HOME, CLAUDE_CONFIG_DIR 모두 work 내부로 지정한다. 실제 provider 실행은 없는 것으로 소스를 확인했다. 전 suite/npm install/global install은 실행하지 않았다.

새 재현 파일: `work/peek-engine-repro.cjs`, 결과: `work/peek-engine-repro-result.json`. 원본 clone 파일은 변경하지 않았다. 새 repro의 full-fail 사례만 실제 ask-start/worker/ask/ask-wait 전체를 통과시키며, freshness 사례는 실제 production proof/receipt 생성 함수와 실제 PostToolUse/Stop를 쓴다. 테스트용 가짜 데이터는 work/peek-engine-sandbox-* 내부에 남겨 두었다.

