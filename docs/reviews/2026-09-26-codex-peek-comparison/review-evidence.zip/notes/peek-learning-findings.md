# codex-peek: scout / MAP / memory / curation 독립 소스 분석

분석 기준: codex-peek `eb7cec1da0b13d2765eaab770c58d177024f423e`. 기존 리뷰와 `docs/research`는 열지 않았다. 소스와 테스트를 직접 읽었다. 아래 파일/행은 이 체크아웃 기준이며 GitHub 영구 링크는 `https://github.com/kimbyungsu/codex-peek/blob/eb7cec1da0b13d2765eaab770c58d177024f423e/<path>#L<line>`로 만들 수 있다. target의 `app`, `core` 구현도 필요한 범위에서 직접 확인했다. 저장소 코드는 수정하지 않았고 실제 AI/provider는 호출하지 않았다.

## 핵심 판단

가져올 가치는 'AI를 더 많이 부르는 구조'보다 **관측과 권위를 분리하는 데이터 모델, 재시도·세대·입력의 결속, 변경을 제안으로 남기는 절차, 불확실성을 통계에 그대로 표시하는 방식**이다. 다만 decision-model_lab은 이미 SQLite 거래, 독립 초안 봉인, 실행별 source snapshot, 호출 사전 예약, 원문 인용 검사를 갖고 있다. 따라서 대체 엔진으로 도입할 이유보다 기존 모델을 확장할 근거가 많다.

여기의 학습은 모델 훈련, reward 학습, 성능 기반 자동 모델 선발이 아니다. 관측 이벤트가 누적되고, 결정론적 규칙으로 상태를 다시 계산하고, 일부 장부 신호를 LLM에게 보여 규칙 변경 후보를 만드는 **명시적 기억 관리**다. 이력의 양이 늘어도 진실이나 모델 품질이 자동 입증되는 것은 아니다.

## 1. 실제 데이터 흐름

### 정찰: 같은 재료를 전달하고 관측으로만 적재

- `bridge/scope-package.js:36-87`: Git status, diff, 식별자 검색, 최근 최대 300개 커밋의 함께 변경된 파일, 기존 관측 장부 등을 꾸러미로 수집한다. Git 이력이 없으면 `:271-337`의 제한적 파일 탐색 경로로 내려간다. `:197`에 seed 8, 파일 1,500, 파일당 512 KiB, depth 6, 총 16 MiB 등 상한이 명시되어 있다.
- `bridge/scout-providers.js:185-210`: provider 선택 뒤 **동일 collectPackage/renderPackageMarkdown** 경로를 공유한다. 준비 확인 실패를 provider failure로 정규화하고, 수집 시점의 baseline을 그대로 전달한다.
- `bridge/scout-providers.js:253-268`: 지도 원문·메타를 보관하고, 출력에서 뽑은 MAP patch 문구를 `type: proposed` 관측 이벤트로 남긴다. 저장 실패를 `saveErr`/`ledgerNote`로 나누어 보고한다. 제안이 곧 승인 정책이 되는 구조는 아니다.
- `bridge/scout-store.js:24-44`: 원문 `.md`와 메타 `.json`을 별도로 쓰며 최근 30개만 유지한다. 지도 보관소는 무제한 감사 원장이 아니다. 두 파일 저장은 한 거래가 아니며, 목록 조회는 메타 손상 때 원문을 감추지 않는다(`:46-55`).

### 관측 장부: 이벤트와 파생 상태의 분리

- `bridge/ledger-events-core.js:36-55`: 허용 이벤트 형식만 파싱하고 손상/미지 이벤트 수를 별도 반환한다.
- `:57-109`: `verified` 승격은 사람 확인 1회, 또는 `claimed + cited + seen=ok + askId` 1개, 또는 비반복노출(`!echoed`) co-cited의 서로 다른 askId 2개 등으로 이루어진다. 구형 기록은 별도 완화 규칙이 있다. 이것은 경험적/휴리스틱 정책이지 통계적으로 검증된 사실 신뢰도 점수가 아니다.
- `:111-271`: 상태를 이벤트에서 유도하며 반박 뒤 확인만으로 복권을 계산한다. `banned > superseded > tombstone > disputed > verified > inferred` 우선순위와 pinned 차선이 있다. `attached` 이벤트는 최신성 갱신에서 제외(`:185-188`)하여 자주 보여준 기억이 다시 자주 선택되는 자기강화를 일부 막는다.
- `:273-302`: 동일 endpoint의 alias는 후보만 제시하고 실제 병합은 명시적 alias 이벤트 이후에만 한다. 비슷한 문장을 자동 통합해 서로 다른 주장의 진릿값을 섞는 것을 피한다.

### MAP: 파일 변경용 그래프와 거래 엔진

- `bridge/map-pipeline.js:383-397`: 같은 patch ID + 같은 operation hash는 멱등, 같은 ID + 다른 내용은 충돌이다.
- `:342-378`: branch/worktree/origin/basis 불일치와 read-set 변경을 구별한다. 대상·파일·인접관계·부재조건·decision index·policy read-set을 비교하여 stale expiry 또는 안전한 rebase로 나눈다.
- `:399-409`: 현행 분류표는 `add_node`, `add_edge`, `set_state`, `add_anchor`, `add_evidence`, `add_condition`을 auto로, 구조/의미 변경 다수를 verifier-resolved로, 정책 변경을 intent-choice로 둔다. `src/project-map.ts:503-515`의 구형 policyTier는 동결·미호출 코드이므로 그 표를 현행 정책으로 읽으면 틀린다.
- `:585-947`: claim, topology, decision, policy, marker, WAL, 완료 기록을 직접 관리한다. 완료 흔적 검증 후 종결만 보충하고, 진행 중 죽은 작업을 복구한다. 구현량 상당 부분이 파일 여러 개를 일관되게 갱신하는 수작업 거래 엔진이다.
- `bridge/map-enrich.js:194-205`: 자동 신설 file node는 code/test/config anchor 하나와 `confidence=candidate`가 필수다. `:2245-2340`에서 patch propose→classify→verifier 필요 여부→apply가 실제 연결된다. 다른 provider의 기존 판단을 강등하는 것은 양측 증거를 포함한 conflict로 회부한다. 같은 provider의 강등은 현행 코드에서 자동으로 verifier 강제되지 않는다(`:2272-2280`); 주변 오래된 주석을 정책으로 믿으면 안 된다.
- `src/project-map.ts:1511-1538`: 저장된 confirmed라도 decision/provenance가 없거나 evidence 파일 지문이 달라지면 effective confidence는 unknown이 된다. **저장 상태와 현재 유효 상태를 분리한 점은 재사용 가치가 높다.**

## 2. '증거'가 실제로 보장하는 범위

`bridge/map-enrich.js:1752-1797`은 호출 직전 동의를 다시 대조하고, 발췌 기준 커밋·발췌 범위·본문 스냅샷을 시도에 결속한다. 같은 스냅샷이 prompt와 인용 검사에 사용되어 호출 도중 파일 편집으로 기준이 바뀌는 문제를 줄인다. 응답은 strict shape와 실제 ID를 검사한다(`:869-962`), 결함 item을 사유와 함께 제외하는 per-item 모드도 있다. 새 node가 발송한 파일 집합 밖에 있으면 거부한다(`:909-923`).

`bridge/map-pipeline.js:692-708`의 verifier resolution은 patchId, opHash, baseDecisionContextHash, support verdict, 비어 있지 않은 typed claims를 요구한다. 적용 시 evidence의 현재 해시를 다시 확인한다(`:782-789`). 이는 **어느 입력/변경/근거에 대한 판단인지, 근거가 바뀌지 않았는지**를 증명한다. 문자열이 실제로 존재한다는 사실은 그 문자열이 주장 전체를 논리적으로 뒷받침한다는 사실과 다르다. `semanticValidateV2` 역시 구조적 조건·정책 적용·ID·상태 기대값 등의 유효성 검사이며 일반 명제의 참/거짓 판정기가 아니다.

특히 L1 장부의 verified/co-cited 승격을 일반 의사결정의 사실 검증에 이식하면 위험하다. 같은 잘못된 자료를 두 번 인용해도 두 askId를 얻을 수 있고, 서로 다른 AI라도 공통 출처/기억의 영향을 공유할 수 있다. codex-peek 자체도 `bridge/contract-lib.js:3511-3520`에서 관측 표본, 과대 확인 가능성, 지도가 안전 보장이 아니라는 주의를 노출한다.

우리 쪽 `app/synthesis.py:1-9`, `:203-207`, `:237-266`은 이미 더 적합한 언어를 사용한다: exact quote와 unsupported addition을 구분하고 **모든 주장 unresolved / factual_check not_performed / agreement_is_verification False**를 유지한다. 이를 지켜야 한다. 지도 코드에서 가져올 것은 '증거 주소와 시점의 결속'이지 `verified` 이름이나 1회/2회 승격 임계가 아니다.

## 3. 라우팅과 재시도

- `bridge/map-router.js:16-62`: pure function으로 mode/readiness/corridor/failure/conflict만 받아 route+reason을 반환한다. 입력 이형은 park, 명시 economy/precision 실패는 park, auto에서 economy 실패 시 precision 한 번 승격, 양측 실패 시 park다. **문맥에 따라 모델을 자율 학습해 고르는 것이 아니라 고정 정책표**다.
- `:69-96`: corridor는 node anchor 파일의 부모 디렉터리 안에 변경 파일이 들어가는지로 판단한다. 기존 디렉터리의 전혀 새로운 고위험 변경도 mapped가 될 수 있으므로 의미적 난이도/위험도 측정으로 해석하면 안 된다.
- `bridge/map-enrich.js:1721-1749`: 실행기에서도 최초+승격+종결 최대 3회 반복으로 위 정책을 실제 제한한다. 원본 변경을 provider 실패와 구별하여 다음 실행으로 보류한다.
- `:1767-1779`, `:2343` 이후: 외부 호출 전 running attempt를 영속한다. 유료 호출 도중 종료되어 호출 여부가 불확실하면 무작정 재호출하지 않고 uncertain-call로 보류한다. 성공/기각 판정은 저장해 적용 재시도에서 verifier를 다시 부르지 않는다(`:2283-2314`).
- `bridge/enrich-calls.js:35-78`: 직전 실패 피드백을 자유문 전체로 재주입하지 않고 닫힌 op/stage/kind 요약으로 만든다. 불신 가능한 모델 문장을 다음 시스템 규칙처럼 재사용하지 않는 좋은 경계다.

우리 앱의 병렬 독립 초안 수집에 '경제형 먼저, 실패하면 고급형'을 그대로 적용하면 실험/비교의 참가자 구성이 뒤바뀐다. 라우팅은 **실행 시작 전 roster와 정책을 고정하는 보조 기능** 또는 초안 공개 후 추가 검증 단계에 한정해야 한다. 기존 요청 참가자를 몰래 교체하는 방식은 부적합하다.

## 4. 기억의 정책 승격과 큐레이션

- `tests/memory-authority.test.js:58-68`은 고쳐진 blocker를 자동 규칙 후보로 올리지 않는 현행 정책을 실행 검증한다. `bridge/contract-lib.js:4817` 이후 reconcile는 주로 기존 후보 이월·고아 복구·정리 역할이고, 명시 rule-propose는 `:5009-5024`에서 finding/campaign/generation에 결속된 후보를 만든다.
- 후보 ID와 승인 세대가 별도 축이다(`bridge/contract-lib.js:4242-4260`). draft는 후보 채택(adopted)이고 실제 승인 지문 반영(applied)과 다르다. 초안 폐기시 후보 복원, 승인 중 중단시 WAL 복구가 있다(`:3955-4028`, `:4133-4138`).
- `bridge/curation.js:104-180`: 현재 승인 규칙 + 장부 신호 + 결정 이력만 입력하며 코드 자체를 읽는 일반 검토기가 아니다. 반복 범위밖 강등, blocker 계보, 사용하지 않은 규칙, 선택 범위 초과 등을 집계한다. repoKey·승인 세대를 필터링한다.
- `:203-210`: 신호가 없거나 같은 input fingerprint 결과가 있으면 모델 호출을 생략한다. `:217-226`의 prompt는 회당 최대 3개, 약한 제안보다 제안 없음, 사건 발생 자체가 규칙 자격은 아님을 지시한다.
- `:252-317`: JSON/필수 형식 손상은 전량 거부, 중복·민감 형태·알 수 없는 refs는 항목별 탈락한다. remove는 axis/index/item fingerprint가 맞아야 한다. toggle은 현재 **held로 기록만 되고 적용하지 않는다**(`:315`). 완전한 자율 규칙 재조직기라고 설명하면 과장이다.
- `:320-371`: 회당 3건·미승인 6건 상한, provisional→result→proposed, read-back, deterministic ID로 후보를 기록한다. `:186-200`은 중단 복구다. proposal이 승인 규칙을 즉시 변경하지 않는다.
- `:484-659`: 주기 관측/신호에 따라 detach 실행한다. 실제 사용자 승인은 별도 후보→draft→stamp 경로다.

좋은 부분은 **회고 결과를 자동 진실/강제 규칙으로 만들지 않고 근거 달린 변경 제안으로 남긴다**는 것이다. 다만 관련 signal ID가 존재하는 것은 신호와 제안 내용의 인과관계를 증명하지 않는다. '미사용'도 과거 관측 기간의 선택 이력이며 쓸모없음의 증거가 아니다. 우리 앱에서는 기록된 주장/반례와 사용자 결정으로 후보를 구성하되, 승격 여부와 적용 범위를 별도 승인 이벤트로 기록하는 소형 구현부터 시작하는 것이 맞다.

## 5. 검색·출처 회수

- `bridge/map-retrieval.js:20-40`: integer IDF 근사값과 deterministic tie ordering을 구현한다. `:65` 이후 씨앗은 상대 파일 경로, backtick, identifier, 인용구 모양을 추출한다. 일반 한국어 질문 전체의 의미 임베딩 검색은 아니다.
- `:147-213`: 검색은 최대 1,500 파일/16 MiB의 substring match + shape weight 3/2/2/1 + IDF다. 실패/상한을 truncated로 표시한다. 단, 상한 전 후보 수집은 readdir 순서이며 모든 환경에서 같은 부분집합을 보장한다는 증거까지는 없다.
- `:216-265`: 요청 의도, 변경 파일, 관측 장부, graph 이웃의 4축 round-robin으로 최대 8개를 선택한다. 한 종류의 후보가 모든 문맥을 차지하는 것을 막고 cap 생략과 아예 후보가 아닌 것을 구별한다.
- `bridge/map-provenance.js:32-91`: 별도 과거결정 retrieval은 제목/찾는말의 bigram+단어 교집합+씨앗 가점이며 한국어 markdown 양식에 결합되어 있다. 의미 검색 모델은 아니다.
- `:133-172`: 검색 영수증에는 질의 원문 대신 지문+길이와 matched IDs를 저장하며, 0건도 남긴다. 과거 결정은 명시적으로 advisory로 주입한다.
- `:446-470`: 자동 수집된 출처는 현재 anchor excerpt hash가 맞는 것만 노출하고 사람 override가 우선한다. 오래된 내용을 삭제하지 않고 현재 효력에서 제외하는 점이 좋다.

우리 앱에 필요한 것은 코드 graph보다 결정의 question / source snapshot / claim / counterexample / user disposition index다. 파일명/낙타등 중심 씨앗을 그대로 가져오면 일반 의사결정 질의의 회수율을 기대할 근거가 없다. SQLite FTS나 단순 태그/키워드부터 시작하고 실제 사용자 질문의 검색 recall/누락률을 측정할 수 있다. 기술 선택은 후속 설계이며 여기서 실험하지 않았다.

## 6. 비용·관측 통계

- `bridge/scout-providers.js:69`, `:91-92`, `:121`, `:171-172`: self는 billed=false(구독 재사용이라는 프로젝트 내 모델), Codex는 plan usage 소모, 일부 CLI token은 null이다. '추가 달러 청구 없음'을 '자원 비용 0'으로 번역하면 안 된다.
- `:218-224`: 실제 시작한 Claude/Codex 호출은 성공/실패/빈 출력과 무관하게 callId로 기록한다. DeepSeek는 API 경계에서 따로 기록한다. 통계는 best-effort라 이 자체를 금전 회계 원장으로 간주할 수 없다.
- `src/map-stats.ts:47-75`: token pair의 알려짐 여부, token-covered calls, token이 없는 호출의 chars를 나누어 집계한다. `:127-227`는 running/interrupted/unknown/missing terminal/parked 등을 구별하고 completion ratio를 5개 이상 표본에서만 표시한다.
- `bridge/enrich-calls.js:100-144`: 옛 기록의 재시도 이력을 unknown으로 보존한다. 기록 없음과 0을 구분한다.

우리 앱은 이미 `app/controller.py:421-440`에서 전체/provider 호출 한도를 거래 안에서 검사하고 호출 전 예약하며 재시작/취소/실패로 환불하지 않는다. `app/store.py:186-228`은 한도를 원장에 고정한다. 기존 방식은 유지하고 **작업별 비용 귀속과 관측 coverage/unknown 표시**를 더하는 정도가 우선이다. codex-peek는 능동 price optimizer나 실증적 cost-quality frontier를 제공하지 않는다.

## 7. 도입 권고 8개 — 기존 앱에 덧붙이는 범위

| 우선순위 | 가져올 원칙 | 우리 코드 연결점 | 최소 결과 / 검증 기준 |
|---|---|---|---|
| P0 | 인용 확인과 사실 판정을 별도 축으로 유지 | `app/synthesis.py:237-266`, `app/report.py:75-78` | 기존 unresolved 유지. 외부 factual check가 추가될 때 check ID/source version/checker/result를 별도 기록. 두 모델 동의만으로 supported 전환 0건 |
| P0 | 모든 후속 평가를 정확한 실행·초안·자료·정책 세대에 결속 | `app/synthesis.py:230-255`, `app/controller.py:375-406`, `core/contract.py:88-93` | report/source hash/policy hash가 바뀌면 재평가 또는 stale 표시. 현재 draft offset/digest 검사를 확장 |
| P1 | finding/claim의 지속적 lifecycle와 사람 disposition | `app/store.py:240-279`, `app/controller.py:979-995` | proposed/accepted/rejected/superseded/reopened 사건. 사건+현재 상태를 같은 SQLite 거래로 저장. callback 중복·옛 attempt는 상태 변경 0건 |
| P1 | 실행별 영수증의 coverage를 정직하게 표시 | `app/report.py:71-78`, `app/controller.py:432-440`, `core/quota.py` | 호출 목적(초안/합성/검증), provider/model, duration, token-known, state-known 분리. 실패 호출 빠짐 0, unknown을 0으로 표시 0건 |
| P1 | 불확실한 외부 호출 재시도와 확정된 로컬 적용 재시도를 분리 | `app/controller.py:726-741`, `:773-811`, `app/state.py` | 기존 UNKNOWN 처리는 유지. 검증 결과가 저장된 이후 출력 생성만 실패한 경우 결과 재사용, 모델 재호출 0건 |
| P2 | 회고는 근거 달린 소수 후보로 제안하고 승인 전 규칙에 반영하지 않기 | 신규 작은 `memory_candidates`/`policy_revisions` 테이블 + `app/store.py` | source event IDs, why, applies-to, if-adopted/if-not, base policy hash. 동일 입력 멱등, 후보 기각/승인과 실제 적용 구분. 처음에는 수동 실행 |
| P2 | 검색 컨텍스트의 다양성 몫·누락 영수증 | `app/synthesis.py:92`의 기존 round-robin 철학 및 향후 retrieval 모듈 | 질문 관련 결정/반례/사용자 제약을 쿼터로 섞고 각 선택 이유 기록. 자료가 없으면 없다고 표시하며 무관 기억으로 채우지 않기 |
| P2 | 순수 정책 함수 + 반례 행렬 테스트 | `app/state.py`, `core/eligibility.py`, `core/membership.py` | gate와 routing을 I/O와 분리하고 가능한 상태 조합/중복/실패/세대 불일치를 검사. LLM 품질 평가는 별도 데이터셋/사람 평가로 분리 |

구현 순서는 새로운 자율 기억기 전체보다 ①현재 report에서 관측 정보 명확화 ②claim disposition 사건 ③세대 묶인 외부 검증 ④작은 회고 후보함이 적절하다. 사용자 체감 가치는 원래 질문의 결정 품질/근거 추적에서 확인해야 하며, MAP 노드 수나 자기검증 횟수를 성과지표로 삼지 않는다.

## 8. 통째로 들여오지 말아야 하는 부분

1. **Git/파일 topology 전체**: branch, HEAD, anchor, read-set, worktree, WAL은 코딩 하네스용 도메인이다. 일반 의사결정은 source/run/claim/policy revision 관계면 충분한지부터 확인할 것.
2. **JSON/JSONL 파일 거래·잠금 엔진**: 우리 `app/store.py:249-269`은 이미 BEGIN IMMEDIATE/COMMIT/ROLLBACK과 event/state 동시 저장을 한다. 외부 API 호출의 exactly-once 문제는 DB만으로 해결되지 않지만, DB 내부 상태에 수백 줄의 파일 WAL 복구를 다시 만들 이유는 없다.
3. **L1의 verified 승격 임계, corridor 난이도**: 코드 결합 관측용 휴리스틱을 사실 신뢰도나 범용 모델 난이도로 재명명하지 말 것.
4. **회당 자동 LLM 큐레이션**: 작은 프로젝트에서 감사/기억 정리 호출이 본 작업보다 비싸질 수 있다. no-signal/same-input skip, 후보 상한만 먼저 가져오고 자동 tick은 실제 편익 관측 뒤 판단할 것.
5. **Claude/Codex CLI 경로·로그·hook에 맞춘 세부 어댑터**: 대상 앱은 이미 adapter/runner/contract 경계를 가지고 있다. provider transport 코드를 혼합해 계정한도와 단일 run 비용을 섞지 말 것.
6. **정찰 gate를 강제 안전 통제로 해석**: `bridge/scout-gate.js:25-26`, `:101-105`, `:144-161`은 세션당 2회 차단 뒤 통과하며 unknown/authority blocked도 로그 후 통과한다. 이는 진행 유도 장치이지 무조건 fail-closed 검증 승인문이 아니다. 필요한 hard gate는 별도다.

## 9. 테스트와 유지보수 평가

좋은 점: 실제 temp filesystem과 fake runner로 멱등, 세대 오염, 다중 실행, 쓰기 실패, 복구를 검증하는 테스트가 풍부하다. `tests/memory-authority.test.js:69` 이후는 후보/승인/복구를 실제 함수와 파일로 검증한다. `tests/curation.test.js`는 page runner 주입 및 가짜 bridge로 provider 호출 없이 끝까지 검사한다. `tests/p8-router.test.js`는 2,592개 조합 반환 불변식을, `tests/map-retrieval-score.test.js:31-41`는 1,125,750개 입력에서 점수 단조성을 확인한다.

한계: 테스트 통과는 정책표대로 움직인다는 증거이며 그 정책표가 좋은 판단을 만든다는 실증이 아니다. 특히 routing 검사의 전체 조합 부분은 예외/허용 반환 확인과 사례 기반 oracle이며 모델 품질 비교가 아니다. `tests/memory-authority.test.js:464-478`, `:566-576` 및 `tests/p8-enrich-run.test.js:362-369` 등에는 소스 문자열/정규식을 검사하는 wiring pin이 있다. 일정한 회귀 방어 역할은 있지만 실제 분기 실행/사용자 UI 동작과 같지 않고 리팩터링에 취약하다.

유지보수 부담: `bridge/contract-lib.js`와 `src/extension.ts`가 각각 수천~만 줄 규모이며 정책/프롬프트/저장/통계/실행/UI가 밀집한다. 생성된 TS→JS 코어 외에도 `bridge/contract-lib.js:3370-3460`의 mini reducer는 `src/ledger-events.ts`/`bridge/ledger-events-core.js`와 판정 규칙을 수동으로 다시 갖는다. `bridge/map-retrieval.js:147-152`의 검색 상수/민감 파일 정규식도 복사+테스트 잠금이다. '두 구현이 같은 정책'을 계속 유지하는 비용을 대상 앱으로 가져오지 말고 pure domain function 하나를 controller/report/UI가 같이 소비하게 할 것.

이번 직접 실행 결과(Node v24.19.0, Windows, 오프라인 fake/순수 함수):

| 시험 파일 | 결과 |
|---|---|
| `tests/p8-router.test.js` | 49/49 통과; 2,592 상태 조합 |
| `tests/map-retrieval-score.test.js` | 21/21 통과; 1,125,750 값 단조성 |
| `tests/map-retrieval-seeds.test.js` | 53/53 통과 |
| `tests/memory-authority.test.js` | 42/42 통과 |
| `tests/curation.test.js` | 26/26 통과 |
| 합계 | **191개 명명된 검사 통과** (전수 값 수를 테스트 케이스 수에 중복 합산하지 않음) |
| `tests/ledger-events.test.js` | `out/ledger-events.js` 없음으로 시작 불가. compile 필요; 제품 실패로 해석하지 않음 |
| `tests/p8-enrich-run.test.js` | 초반 실제 파일 적용/승격/재시도 사례가 진행됨을 확인했으나 전체 종료 결과를 확보하지 못해 중단. 통과 수에 포함하지 않음 |

후자의 긴 시험은 보고 취합을 위해 이 작업이 시작한 해당 node process와 자식만 종료했다. 전체 npm test, 컴파일, 실제 provider 연동, 실제 품질·비용 절감 실험은 이 분담 리뷰에서 완료했다고 주장하지 않는다.
